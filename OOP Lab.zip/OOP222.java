package OOP;
import java.util.Scanner;
public class OOP222 {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        String studentFullName = "";  
        String idNumber = "";  
        int numberOfLastSemesterSubjects = 0;
        int[] marks = new int[0];  
        final int MAX_NUMBER_SUBJECTS = 10;
        boolean detailsEntered = false; // Flag to check if details are entered

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Enter Student Details");
            System.out.println("2. Calculate Total Marks and Percentage");
            System.out.println("3. Display Student Details");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            if (choice == 1) {
                System.out.print("Enter Student Name: ");
                studentFullName = scanner.nextLine().trim();

                System.out.print("Enter ID Number: ");
                idNumber = scanner.nextLine().trim(); // Fixed issue

                System.out.print("How many subjects you studied last semester? (1-10): ");
                numberOfLastSemesterSubjects = scanner.nextInt();

                if (numberOfLastSemesterSubjects > MAX_NUMBER_SUBJECTS || numberOfLastSemesterSubjects < 4) {
                    System.out.println("Invalid number of subjects. Defaulting to 4.");
                    numberOfLastSemesterSubjects = MAX_NUMBER_SUBJECTS;
                }

                marks = new int[numberOfLastSemesterSubjects];  // Properly initialize array
                System.out.print("Enter Marks for " + numberOfLastSemesterSubjects + " subjects: ");
                for (int i = 0; i < numberOfLastSemesterSubjects; i++) {
                    marks[i] = scanner.nextInt();
                }

                detailsEntered = true;  // Set flag to true
            } 
            else if (choice == 2) {
                if (!detailsEntered) {
                    System.out.println("Please enter student details first (Option 1).");
                    continue;
                }
                int totalMarks = 0;
                for (int mark : marks) {
                    totalMarks += mark;
                }
                double percentage = ((double) totalMarks / (numberOfLastSemesterSubjects * 100)) * 100;
                System.out.println("Total Marks: " + totalMarks);
                System.out.println("Percentage: " + Math.round(percentage * 10.0) / 10.0 + "%");
            } 
            else if (choice == 3) {
                if (!detailsEntered) {
                    System.out.println("Please enter student details first (Option 1).");
                    continue;
                }
                System.out.println("\nStudent Details:");
                System.out.println("Name: " + studentFullName);
                System.out.println("ID Number: " + idNumber);

                int totalMarks = 0;
                for (int mark : marks) {
                    totalMarks += mark;
                }
                double percentage = ((double) totalMarks / (numberOfLastSemesterSubjects * 100)) * 100;
                
                System.out.println("Total Marks: " + totalMarks);
                System.out.println("Percentage: " + Math.round(percentage * 10.0) / 10.0 + "%");
                
                if (percentage >= 60) {
                    System.out.println("Status: Passed");
                } else {
                    System.out.println("Status: Failed");
                }
            } 
            else if (choice == 4) {
                System.out.println("Good luck!");
                scanner.close();
                break;
            } 
            else {
                System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}